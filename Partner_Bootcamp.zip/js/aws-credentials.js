function initAWS(){ 
 	AWS.config.region = 'ap-southeast-1'; 
   } 

   
 $(document).ready(initAWS); 
    

   function getRegion(){ 
      return 'ap-southeast-1';
   } 

   function getGatewayAPI(){ 
      return 'undefined';
   } 

   function getInstanceId(){ 
      return 'undefined';
   } 

   function getInstanceName(){ 
      return 'undefined';
   } 

