import { 
    ContactClient,
    ContactAcceptedEventData, 
    ContactAcceptedHandler
} from "@amazon-connect/contact";
import { AppContactScope } from "@amazon-connect/app";

const handler: ContactAcceptedHandler = async (data: ContactAcceptedEventData) => {
    console.log(data);
};

// Subscribe to the contact accepted topic using the above handler
contactClient.onAccepted(handler, AppContactScope.CurrentContactId);  